#encoding:utf8

'''  ValidationError 异常  '''

class ValidationError(ValueError):
              pass